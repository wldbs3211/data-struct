#pragma once
#include <iostream>
using namespace std;

class Chain;

class Node {
	friend class Chain;
private:
	int vertex;
	Node *link;

public:
	Node(int vertex) :vertex(vertex), link(NULL) { }
	Node() { vertex = 0; link = NULL; }
	Node* getLink() { return link; }
	int getVertex() { return vertex; }
	void setLink(Node* n) { link = n; }
	void setVertex(int v) { vertex = v; }
};

class Chain {
private:
	Node *first; 
public:
	Chain() { first = NULL; }
	~Chain() {}
	Node* getFirst() { return first; }
	void setFirst(Node* n) { first = n; }
};