#pragma once
#include <string>
#include <stack>
#include <queue>
#include <iostream>
#include <fstream>
#include "ChainNode.h"
using namespace std;

class Graph
{
protected:
	int vertex;	// ���� ��
	int edge;	// ���� ��
	bool* visited; // �湮 Ȯ��
	
public:
	Graph() {}
	Graph(int v, int e)
	{
		vertex = v;
		edge = e;
	}
	~Graph() {}

	bool isEmpty() const { return vertex; }
	int numberOfVertices() const { return vertex; }
	int numberOfEdges() const { return edge; }
	virtual int degree(int u) const = 0;
	virtual bool existEdge(int u, int v) const = 0;
	virtual void insertVertex(int v) = 0;
	virtual void insertEdge(int u, int v) = 0;
	virtual void deleteVertex(int v) = 0;
	virtual void deleteEdge(int u, int v) = 0;
	virtual void DFS()
	{
		visited = new bool[vertex]; 
		fill(visited, visited + vertex, false); 
		DFS(0);
		delete[] visited;
	}
	virtual void DFS(const int v){}
	virtual void BFS(int v) {}

	virtual void DFSComponents() {}
	virtual void BFSComponents() {}
};