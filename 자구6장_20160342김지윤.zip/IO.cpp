#include "IO.h"

void IO::readS(string fileName, LinkedGraph& lg)
{
	ifstream fin;
	fin.open(fileName);
	if (fin.fail())
		throw "���� ���� ����";

	int vertex, v, e;

	fin >> vertex;
	lg.setVertex(vertex);

	while (!fin.eof())
	{
		fin >> v >> e;
		if (v == -1)
			break;
		lg.insertVertex(v);
		lg.insertEdge(e, v);
		lg.insertVertex(e);
		lg.insertEdge(v, e);

		lg.setMatrix(v, e);
		lg.setMatrix(e, v);
	}
	fin.close();
}

void IO::readT(string str, TopologicalOrder& to)
{
	ifstream fin;
	fin.open(str);
	if (fin.fail())
		throw "���� ���� ����";

	int vertex, v, e;

	fin >> vertex;
	to.setVertex(vertex); 

	while (!fin.eof())
	{
		fin >> v >> e;
		if (v == -1)
			break;
		to.insertVertex(e);
		to.insertEdge(v, e);
	}
	fin.close();
}