#pragma once
#include <iostream>
#include <fstream>
#include "LinkedGraph.h"
#include "TopologicalOrder.h"
using namespace std;
class IO
{
public:
	void readS(string fileName, LinkedGraph& lg);
	void readT(string str, TopologicalOrder&  to);

	IO() {}
	~IO() {}
};

