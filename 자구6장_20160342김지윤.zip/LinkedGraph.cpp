#include "LinkedGraph.h"

void LinkedGraph::insertEdge(int u, int v)
{
	Node* current = adjLists[u].getFirst();

	if (current != NULL)
	{
		curNode->setLink(current);
		adjLists[u].setFirst(curNode);
	}
	else if (current == NULL)
		adjLists[u].setFirst(curNode);
}

void LinkedGraph::setVertex(int v)
{
	vertex = v;
	adjLists = new Chain[vertex];

	matrix = new int*[vertex];

	for (int i = 0; i < vertex; i++)
	{
		matrix[i] = new int[vertex];
		for (int j = 0; j < vertex; j++)
		{
			matrix[i][j] = 0;
		}
	}
}

void LinkedGraph::Matrixs()
{
	cout << "�Էµ� �׷����� ���� ��� ǥ��" << endl;

	for (int i = 0; i < vertex; i++)
	{
		cout << "| ";
		for (int j = 0; j < vertex; j++)
		{
			cout << matrix[i][j] << " ";
		}
		cout << "| " << endl;
	}
	cout << endl;
}

void LinkedGraph::AdjLists()
{
	cout << "�Էµ� �׷����� ��������Ʈ ǥ��" << endl;
	for (int i = 0; i < vertex; i++)
	{
		Node* current = adjLists[i].getFirst();

		if (current == NULL)
		{
			cout << i << " -> null" << endl;
		}
		else
		{
			cout << i << " -> ";

			while (current != NULL)
			{
				if (current->getLink() == NULL)
					cout << current->getVertex();
				else
					cout << current->getVertex() << "-";
				current = current->getLink();
			}
			cout << endl;
		}
	}
	cout << endl;
}

void LinkedGraph::DFS(const int v)
{
	if (!visited[v])
		cout << v << " ";
	visited[v] = true;

	Node* current = adjLists[v].getFirst();
	while (current != NULL)
	{
		if (!visited[current->getVertex()])
			DFS(current->getVertex());
		current = current->getLink();
	}
}
void LinkedGraph::BFS(int v)
{
	visited[v] = true;

	queue<int> q;
	q.push(v);

	while (!q.empty())
	{
		v = q.front();
		cout << v << " ";
		q.pop();

		Node* current = adjLists[v].getFirst();
		while (current != NULL)
		{
			if (!visited[current->getVertex()])
				q.push(current->getVertex());
			visited[current->getVertex()] = true;
			current = current->getLink();
		}
	}
}

void LinkedGraph::printDFSMatrix()
{
	cout << "������" << endl;
	cout << "1.������� + DFS" << endl;
	stack<int> stack;
	bool* visited = new bool[vertex];
	bool isCheck = true;
	fill(visited, visited + vertex, false);
	int count = 1;
	int count2 = 0;

	for (int i = 0; i < vertex; i++)
	{
		isCheck = true;
		if (visited[i] == false)
		{
			count2 = 0;
			cout << "������" << count << " - ";
			count++;
			for (int k = 0; k < vertex; k++)
			{
				if (matrix[i][k] == 1 && visited[k] == false)
				{
					count2 = 1;
					isCheck = true;
					if (visited[i] == false)
					{
						cout << i << " ";
					}
					for (int j = 0; (j < vertex && isCheck); j++)
					{
						if (matrix[i][j] == 1 && visited[j] == false)
						{
							stack.push(j);
							isCheck = false;
						}
					}
					visited[i] = true;

					while (stack.size() > 0)
					{
						int n = stack.top();
						stack.pop();
						if (visited[n] == false)
						{
							cout << n << " ";
						}
						visited[n] = true;
						for (int j = vertex - 1; j >= 0; j--)
						{
							if (matrix[n][j] == 1 && visited[j] == false)
							{
								stack.push(j);

							}
						}
					}
				}
			}
			if (count2 == 0)
			{
				cout << i << endl;
			}
			else
			{
				cout << endl;
			}
		}
	}

}

void LinkedGraph::printBFSMatrix()
{
	cout << "2.������� + BFS" << endl;
	queue<int> queue;
	bool* visited = new bool[vertex];
	bool isCheck = true;
	fill(visited, visited + vertex, false);
	int count = 1;

	for (int i = 0; i < vertex; i++)
	{
		isCheck = true;
		if (visited[i] == false)
		{
			cout << "������" << count << " - ";
			count++;
			visited[i] = true;
			for (int j = 0; j < vertex; j++)
			{
				if (matrix[i][j] == 1)
				{
					if (isCheck)
					{
						cout << i << " ";
						isCheck = false;
					}
					queue.push(j);
				}
			}
			if (queue.size() == 0)
			{
				cout << i << endl;
			}
			while (queue.size() > 0)
			{
				int n = queue.front();
				queue.pop();
				if (visited[n] == false)
				{
					cout << n << " ";
				}
				visited[n] = true;
				for (int j = 0; j < vertex; j++)
				{
					if (matrix[n][j] == 1 && visited[j] == false)
					{
						queue.push(j);
					}
				}
			}
			cout << endl;
		}
	}
	cout << endl;
}

void LinkedGraph::DFSComponents()
{
	visited = new bool[vertex];
	fill(visited, visited + vertex, false);
	int count = 0;

	cout << "������" << endl;
	cout << "3.��������Ʈ + DFS" << endl;

	for (int i = 0; i < vertex; i++)
	{
		if (!visited[i])
		{
			count++;
			cout << "������" << count << " - ";
			DFS(i);
			cout << endl;
		}
	}
}

void LinkedGraph::BFSComponents()
{
	visited = new bool[vertex];
	fill(visited, visited + vertex, false);
	int count = 0;

	cout << "4.��������Ʈ + BFS" << endl;

	for (int i = 0; i < vertex; i++)
	{
		if (!visited[i])
		{
			count++;
			cout << "������" << count << " - ";
			BFS(i);
			cout << endl;
		}
	}
}
