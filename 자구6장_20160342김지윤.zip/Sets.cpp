#include "Sets.h"

Sets::Sets(int numberOfElements)
{
	if (numberOfElements < 2)
		throw "Must have at least 2 elements.";
	n = numberOfElements;
	parent = new int[n];
	fill(parent, parent + n, -1);
}

void Sets::weightedUnion(int i, int j)
{
	int temp = parent[i] + parent[j];
	if (parent[i] > parent[j])
	{
		parent[i] = j;
		parent[j] = temp;
	}
	else
	{
		parent[j] = i;
		parent[i] = temp;
	}
}
int Sets::collapsingFind(int i)
{
	int r = 0;
	for (r = i; parent[r] >= 0; r = parent[r]);
	while (i != r)
	{
		int s = parent[i];
		parent[i] = r;
		i = s;

	}
	return r;
}