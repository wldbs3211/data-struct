#pragma once
#include <iostream>
using namespace std;

class Sets
{
private:
	int* parent;
	int n;
public:
	Sets(){}
	Sets(int numberOfElements);
	~Sets(){}

	void weightedUnion(int i, int j);
	int collapsingFind(int i);
	int getNumber() { return n; }
};
