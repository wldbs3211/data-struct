#include "TopologicalOrder.h"

void TopologicalOrder::insertEdge(int u, int v)
{
	count[v]++;
	Node* current = adjLists[u].getFirst();

	if (current != NULL)
	{
		curNode->setLink(current);
		adjLists[u].setFirst(curNode);
	}
	else if (current == NULL)
		adjLists[u].setFirst(curNode);
}

void TopologicalOrder::setVertex(int v)
{
	vertex = v;
	adjLists = new Chain[vertex];
	count = new int[vertex];
	for (int i = 0; i < vertex; i++)
		count[i] = 0;
}

void TopologicalOrder::topological()
{
	cout << "������ �ϳ��� ���� ���� : ";
	int i = 0;
	int cnt;
	while (true)
	{
		cnt = 0;
		for (i = 0; i < vertex; i++)
		{
			if (count[i] == 0)
			{
				cout << i << " ";
				count[i] = -1;
				Node* node = new Node();
				node = adjLists[i].getFirst();

				while (node != NULL)
				{
					count[node->getVertex()]--;
					node = node->getLink();
				}
			}
		}
		for (int j = 0; j < vertex; j++)
		{
			if (count[j] == -1)
			{
				cnt++;
			}
		}
		if (cnt == vertex)
		{
			break;
		}
		else if (i == vertex)
		{
			i = 0;
		}
	}
	cout << endl;
}