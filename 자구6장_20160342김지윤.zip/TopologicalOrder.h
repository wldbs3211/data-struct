#pragma once
#include "Graph.h"
#include "LinkedGraph.h"
class TopologicalOrder : public Graph
{
private:
	int vertex; //���� ��
	Chain* adjLists; //��������Ʈ
	Node* curNode; //�����Ʈ
	int* count; //��������
public:
	TopologicalOrder()
	{
		curNode = NULL;
		adjLists = NULL;
		count = NULL;
	}
	~TopologicalOrder() {}

	bool isEmpty() const { return vertex; }
	int numberOfVertices() const { return vertex; }
	int numberOfEdges() const { return edge; }
	virtual int degree(int u) const { return 0; }
	virtual bool existEdge(int u, int v) const { return true; }
	virtual void insertVertex(int v) { curNode = new Node(v); }
	virtual void insertEdge(int u, int v);
	virtual void deleteVertex(int v) {}
	virtual void deleteEdge(int u, int v) {}

	void setVertex(int v);
	void topological();
};