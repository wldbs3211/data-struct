#include "ArrayMaker.h"

int* ArrayMaker::makeIntArr(const int SIZE, ARRAY_TYPE type)
{
    srand((unsigned int)time(NULL));
    int* arr = new int[SIZE + 1];

    switch (type)
    {
    case ASC:
    {
        for (int i = 1; i <= SIZE; i++)
            arr[i] = i;
        break;
    }

    case DESC:
    {
        int val = SIZE;
        for (int i = 1; i <= SIZE; i++)
            arr[i] = val--;
        break;
    }

    case RAND:
    {
        for (int i = 1; i <= SIZE; i++)
            arr[i] = rand() % (SIZE - 1) + 1;
        break;
    }
    }
    return arr;
}

unsigned int * ArrayMaker::makeUIntArr(const int SIZE, ARRAY_TYPE type)
{
    srand((unsigned int)time(NULL));
    unsigned int* arr = new unsigned int[SIZE + 1];

    for (int i = 1; i <= SIZE; i++)
        arr[i] = rand() % (SIZE - 1) + 1;

    return arr;
}

double* ArrayMaker::makeDblArr(const int SIZE, ARRAY_TYPE type)
{
    srand((unsigned int)time(NULL));
    double* arr = new double[SIZE + 1];

    switch (type)
    {
    case ASC:
    {
        for (int i = 1; i <= SIZE; i++)
            arr[i] = i + 0.01*(double)(rand() % 100);
        break;
    }

    case DESC:
    {
        double val = SIZE;
        for (int i = 1; i <= SIZE; i++)
        {
            arr[i] = val;
            val = val - 0.01* (double)(rand() % 100);
        }
        break;
    }

    case RAND:
    {
        for (int i = 1; i <= SIZE; i++)
            arr[i] = (rand() % (SIZE - 1) + 1) + 0.01*(double)(rand() % 100);
        break;
    }
    }
    return arr;
}

string* ArrayMaker::makeStrArr(const int SIZE, ARRAY_TYPE type)
{
    srand((unsigned int)time(NULL));
    string* arr = new string[SIZE + 1];

    for (int i = 1; i <= SIZE; i++)
    {
        int len = (rand() % (STRMAX - 1) + 1);
        while (len--) arr[i] += STR_SOURCE[(rand() % (STR_SOURCE.length()))];
    }

    switch (type)
    {
    case ASC: qsort(arr+1, SIZE, sizeof(string), cmp<string>); break;
    case DESC: qsort(arr + 1, SIZE, sizeof(string), decmp<string>); break;
    }

    return arr;
}

Student * ArrayMaker::makeStdArr(const int SIZE, ARRAY_TYPE type)
{
    srand((unsigned int)time(NULL));
    Student* arr = new Student[SIZE + 1];

    for (int i = 1; i <= SIZE; i++)
    {
        string name;
        while (name.length()<3) name += STR_SOURCE[(rand() % (STR_SOURCE.length()))];
        int kor = (rand() % (100) + 1);
        int eng = (rand() % (100) + 1);
        int math = (rand() % (100) + 1);
        arr[i] = Student(i, kor, eng, math, name);
    }

    switch (type)
    {
    case ASC: qsort(arr + 1, SIZE, sizeof(Student), cmp<Student>); break;
    case DESC: qsort(arr + 1, SIZE, sizeof(Student), decmp<Student>); break;
    }
    return arr;
}
