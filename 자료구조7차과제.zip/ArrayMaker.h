#pragma once
#include "CommonHeader.h"

enum ARRAY_TYPE { ASC = 0, DESC, RAND} ;

class ArrayMaker
{
public:
    int* makeIntArr(const int SIZE, ARRAY_TYPE type);
    unsigned int* makeUIntArr(const int SIZE, ARRAY_TYPE type);
    double* makeDblArr(const int SIZE, ARRAY_TYPE type);
    string* makeStrArr(const int SIZE, ARRAY_TYPE type);
    Student* makeStdArr(const int SIZE, ARRAY_TYPE type);
};