#pragma once
#include <iostream>
#include <ctime>
#include <cmath>
#include "Student.h"

using namespace std;

const int EXIT = -1;
const int SORT_KIND = 17;
const int STRMAX = 5;
const int RAD_SIZE = 1000000;
const string STR_SOURCE = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
enum DATA_ENUM { INTEGER =1, DOUBLE, STRING, STUDENT};


const string SORT_NAME[SORT_KIND] = { 
    "Bubble", "Selection", 
    "Insertion", "Linked Insertion", "Binary Insertion",
    "Quick", "Median of Three Quick", "Median of Three Stack Quick",
    "Merge", "Recursive Merge", "Natural Merge",
    "Heap",
    "Modulo Decimal Radix Sort",
    "Modulo Hexadecimal Radix Sort",
    "Bitwise Hexadecimal Radix Sort",
    "std::sort", "c_qsort"
};

enum SORT_ENUM { 
    BUBBLE = 0, SELECTION,
    INSERTION, LINKED_INSERTION, BINARY_INSERTION,
    QUICK, MEDIAN_OF_THREE_QUICK, MOT_STK_QUICK,
    MERGE, RECURSIVE_MERGE, NAT_MERGE,
    HEAP,
    MOD_DEC_RADIX,
    MOD_HEX_RADIX,
    BIT_HEX_RADIX,
    STD_SORT, C_QSORT
};

template <typename T>
int cmp(const void* a, const void* b)
{
    if(*(T*)a < *(T*)b) return -1;
    else if(*(T*)a == *(T*)b) return 0;
    else return 1;
}

template <typename T>
int decmp(const void* a, const void* b)
{
    if (*(T*)a < *(T*)b) return 1;
    else if (*(T*)a == *(T*)b) return 0;
    else return -1;
}