#pragma once
#include "CommonHeader.h"

template <typename T>
class Node
{
private:
    T data;
    Node* next;

public:
    Node(T _data = T(), Node* _next = NULL) : data(_data), next(_next) {}
    void setNext(Node* _next) { next = _next; }
    T getData() { return data; }
    Node* getNext() { return next; }

};

template <typename T>
class LinkedList
{
private:
    Node<T> head;

public:
    LinkedList() { head.setNext(NULL); }
    ~LinkedList();

    void insertFront(T item);
    void insertBack(T item);
    void removeFront();
    void removeBack();
    Node<T>& getIter() { return head; }
};

template<typename T>
LinkedList<T>::~LinkedList()
{
    Node<T>* temp;
    Node<T>* iter = head.getNext();

    while (iter)
    {
        temp = iter->getNext();
        delete iter;
        iter = temp;
    }
}

template<typename T>
void LinkedList<T>::insertFront(T item)
{
    head.setNext(new Node<T>(item, head.getNext()));
}

template<typename T>
void LinkedList<T>::insertBack(T item)
{
    Node<T>* iter = &head;

    while (iter->getNext())
        iter = iter->getNext();

    iter->setNext(new Node<T>(item, NULL));
}

template<typename T>
void LinkedList<T>::removeFront()
{
    if (!head.getNext()) return;

    Node<T>* target = head.getNext();
    if (target)
    {
        head.setNext(target->getNext());
        delete target;
    }
}

template<typename T>
void LinkedList<T>::removeBack()
{
    if (!head.getNext()) return;

    Node<T>* iter = head.getNext();
    Node<T>* target = head.getNext();

    while (iter->getNext())
    {
        target = iter;
        iter = iter->getNext();
    }
    target->setNext(NULL);
    delete iter;
}
