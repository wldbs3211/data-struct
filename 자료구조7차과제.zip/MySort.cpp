#include "MySort.h"

void modDecRadixSort(unsigned int * arr, const int SIZE)
{
    unsigned int maxVal = arr[1];
    for(int i=2; i<=SIZE; i++)
        if(maxVal < arr[i]) maxVal = arr[i];
    
    myRadixSort(arr, SIZE, getNumD(maxVal, 10), 10);
}

void modHexRadixSort(unsigned int * arr, const int SIZE)
{
    int maxVal = arr[1];
    for (int i = 2; i <= SIZE; i++)
        if (maxVal < arr[i]) maxVal = arr[i];

    myRadixSort(arr, SIZE, getNumD(maxVal, 16), 16);
}

void bitHexRadixSort(unsigned int * arr, const int SIZE)
{
    int maxVal = arr[1];
    for (int i = 2; i <= SIZE; i++)
        if (maxVal < arr[i]) maxVal = arr[i];

    bitHexRadixSort(arr, SIZE, getNumD(maxVal, 16));
}

void bitHexRadixSort(unsigned int * arr, const int SIZE, int D)
{
    int* count = new int[16];

    for (int i = 1; i <= D; i++)
        myCountingSort(arr, count, SIZE, i, 16, hexaDigitByBitwise);

    delete[] count;
}

int getNumD(unsigned int num, int div)
{
    int res = 1;

    while (num / div)
    {
        num /= div;
        res++;
    }

    return res;
}

int digitByModulo(unsigned int val, int D, const int R)
{
    int div = 0;
    while (D--)
    {
        div = val % R;
        val = val / R;
    }
    return div;
}

int hexaDigitByBitwise(unsigned int val, int D, const int MASK)
{
    int res = 0;
    while (D--)
    {
        res = val & MASK-1;
        val = val >> 4;
    }
    return res;
}

void myCountingSort(unsigned int* arr, int* count, const int SIZE, const int D, const int R, int(*fpDigit)(unsigned int, int, const int))
{
    unsigned int* result = new unsigned int[SIZE + 1];

    for (int i = 0; i < R; i++)
        count[i] = 0;

    for (int i = 1; i <= SIZE; i++)
        count[fpDigit(arr[i], D, R)]++;

    for (int i = 1; i < R; i++)
        count[i] += count[i - 1];

    for (int i = SIZE; i >= 1; i--)
        result[ count[fpDigit(arr[i], D, R)]-- ] = arr[i];

    for(int i=1; i<=SIZE; i++)
        arr[i] = result[i];

    delete[] result;
}

void myRadixSort(unsigned int* arr, const int SIZE, const int D, const int R)
{
    int* count = new int[R];

    for (int i = 1; i <= D; i++)
        myCountingSort(arr, count, SIZE, i, R, digitByModulo);

    delete[] count;
}
