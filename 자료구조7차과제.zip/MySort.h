#pragma once
#include "CommonHeader.h"
#include "LinkedList.h"
#include "Stack.h"
#include "Queue.h"

void modDecRadixSort(unsigned int* arr, const int SIZE);
void modHexRadixSort(unsigned int* arr, const int SIZE);
void bitHexRadixSort(unsigned int* arr, const int SIZE);

int getNumD(unsigned int num, int div);
int digitByModulo(unsigned int val, int D, const int R);
int hexaDigitByBitwise(unsigned int val, int D, const int MASK);

void bitHexRadixSort(unsigned int * arr, const int SIZE, int D);
void myRadixSort(unsigned int* arr, const int SIZE, const int D, const int R);
void myCountingSort(unsigned int* arr, int* count, const int SIZE, const int D, const int R, int(*fpDigit)(unsigned int, int, const int));

template <typename T>
void mySwap(T& a, T& b)
{
    T temp = a;
    a = b;
    b = temp;
}

template <typename T>
bool isSorted(T* arr, const int SIZE)
{
    for (int i = 1; i < SIZE; i++)
        if (arr[i + 1] < arr[i]) return false;

    return true;
}

template <typename T>
void mySelectionSort(T* arr, const int SIZE)
{
    int min;
    for (int i = 1; i <= SIZE; i++)
    {
        min = i;
        for (int j = i+1; j <= SIZE; j++)
            if (arr[j] < arr[min]) min = j;

        mySwap<T>(arr[i], arr[min]);
    }
}

template <typename T>
void myBubbleSort(T* arr, const int SIZE)
{
    for (int i = SIZE; i > 1; i--)
        for (int j = 1; j < i; j++)
            if (arr[j + 1] < arr[j])
                mySwap<T>(arr[j], arr[j + 1]);
}

template <typename T>
void myInsertionSort(T* arr, const int SIZE)
{
    for (int i = 2; i <= SIZE; i++)
    {
        arr[0] = arr[i];

        int idx = i-1;
        while (arr[0] < arr[idx])
        {
            arr[idx + 1] = arr[idx];
            idx--;
        }

        arr[idx+1]= arr[0];
    }
}

template <typename T>
void myLinkedInsertionSort(T* arr, const int SIZE)
{
    Node<T>* iter;
    Node<T>* temp;
    LinkedList<T> list;
    
    // reverse list push & reverse pop
    list.insertBack(arr[1]);
    for (int i = 2; i <= SIZE; i++) 
    {
        list.insertBack(arr[i]);
        
        temp = NULL;
        iter = list.getIter().getNext();
        while (arr[i] < iter->getData())
        {
            temp = iter;
            iter = iter->getNext();
        }
        if(temp) temp->setNext(new Node<T>(arr[i],iter));
        else list.insertFront(arr[i]);

        list.removeBack();
    }

    iter = list.getIter().getNext();
    for (int i = SIZE; i >= 1; i--)
    {
        arr[i] = iter->getData();
        iter = iter->getNext();
    }
}

template <typename T>
int myBinarySearch(T* arr, const int SIZE, T& key)
{
    int low = 1, high = SIZE, mid;
     
    while (low <= high)
    { 
        mid = (low + high) / 2; 
        if (key < arr[mid]) high = mid - 1; 
        else if (arr[mid] < key) low = mid + 1; 
        else return mid;
    }

    return low;
}

template <typename T>
void myBinaryInsertionSort(T* arr, const int SIZE)
{ 
    for (int i = 2; i <= SIZE; i++)
    {
        arr[0] = arr[i];    // array's 0 index is a sorting key
        int idx, idxLimit = myBinarySearch(arr, i-1, arr[i]);
         
        for (idx = i - 1; idx >=idxLimit; idx--) 
            arr[idx + 1] = arr[idx]; 
        arr[idxLimit] = arr[0]; 
    }
}

/* Quick Sort */
template <typename T>
void myQuickSort(T* arr, const int SIZE)
{
    myQuickSort<T>(arr, 1, SIZE);
}

template <typename T>
void myQuickSort(T* arr, const int LEFT, const int RIGHT)
{
    int left = LEFT, right = RIGHT;
    T pivot = arr[LEFT];

    while (left <= right)
    {
        while (arr[left] < pivot) left++;
        while (pivot < arr[right]) right--;

        if (left <= right)
        {
            mySwap<T>(arr[left], arr[right]);
            left++;
            right--;
        }
    }

    if (left < RIGHT) myQuickSort(arr, left, RIGHT);
    if (LEFT < right) myQuickSort(arr, LEFT, right);
}

/* Median Of Three Quick Sort */
template <typename T>
T medianOfThree(T* arr, const int LEFT, const int MID, const int RIGHT)
{
    if (arr[MID] < arr[LEFT]) swap(arr[LEFT], arr[MID]);
    if (arr[RIGHT] < arr[MID]) swap(arr[MID], arr[RIGHT]);
    if (arr[MID] < arr[LEFT]) swap(arr[LEFT], arr[MID]);

    return arr[MID];
}

template <typename T>
void myMotQuickSort(T* arr, const int SIZE)
{
    myMotQuickSort<T>(arr, 1, SIZE);
}

template <typename T>
void myMotQuickSort(T* arr, const int LEFT, const int RIGHT)
{
    int left = LEFT, right = RIGHT;
    T pivot = medianOfThree<T>(arr, LEFT, (LEFT + RIGHT) >> 1, RIGHT);

    if(RIGHT-LEFT ==2) return;

    while (left <= right)
    {
        while (arr[left] < pivot) left++;
        while (pivot < arr[right]) right--;

        if (left <= right)
        {
            mySwap<T>(arr[left], arr[right]);
            left++;
            right--;
        }
    }

    if (left < RIGHT) myMotQuickSort(arr, left, RIGHT);
    if (LEFT < right) myMotQuickSort(arr, LEFT, right);
}

template <typename T>
void myMotStkQuickSort(T* arr, const int SIZE)
{
    Stack<int> stk(SIZE+1);
    int left = 1, right = SIZE;
    T pivot;

    stk.push(right);
    stk.push(left);
    while (!stk.isEmpty())
    {
        left = stk.getTop();
        stk.pop();
        right = stk.getTop();
        stk.pop();

        int lidx = left;
        int ridx = right;
        pivot = medianOfThree(arr, left, (left+right)>>1, right);

        while (lidx <= ridx)
        {
            while (arr[lidx] < pivot) lidx++;
            while (pivot < arr[ridx]) ridx--;

            if (lidx <= ridx)
            {
                mySwap(arr[lidx], arr[ridx]);
                lidx++;
                ridx--;
            }
        }

        if (lidx < right)
        {
            stk.push(right);
            stk.push(lidx);
        }
        if (left < ridx)
        {
            stk.push(ridx);
            stk.push(left);
        }
    }
}
/* Recursive Merge Sort */
template <typename T>
void relocation(T* arr, int* link, const int SIZE, int first)
{
    for (int i = 1; i < SIZE; i++)
    {
        while (first < i) first = link[first];
        int q = link[first];
        if (first != i)
        {
            mySwap<T>(arr[i], arr[first]);
            link[first] = link[i];
            link[i] = first;
        }
        first = q;
    }
}

template <typename T>
void myRMergeSort(T* arr, const int SIZE)
{
    int* link = new int[SIZE+1];
    for (int i = 0; i <= SIZE; i++) link[i] = 0;

    myRMergeSort<T>(arr, link, 1, SIZE);
    relocation<T>(arr, link, SIZE, 0);

    delete[] link;
}

template <typename T>
int listMerge(T* arr, int* link, const int S1, const int S2)
{
    int resIter = 0, i1 = S1, i2 = S2;
    while(i1&&i2)
    {
        if (arr[i1] <= arr[i2])
        {
            link[resIter] = i1;
            resIter = i1;
            i1 = link[i1];
        }
        else
        {
            link[resIter] = i2;
            resIter = i2;
            i2 = link[i2];
        }
    }

    if(i1== 0) link[resIter] = i2;
    else link[resIter] = i1;
    return link[0];
}

template <typename T>
int myRMergeSort(T* arr, int* link, const int LEFT, const int RIGHT)
{
    if(LEFT >= RIGHT) return LEFT;
    int mid = (LEFT+RIGHT) / 2;
    return listMerge<T>(arr, link, 
        myRMergeSort<T>(arr, link, LEFT, mid),
        myRMergeSort<T>(arr, link, mid+1, RIGHT));
}

 /* Heap Sort */
template <typename T>
void myHeapSort(T* arr, const int SIZE)
{
    for(int i=SIZE>>1; i>=1; i--)
        adjust(arr, i, SIZE);

    for (int i = SIZE - 1; i >= 1; i--)
    {
        mySwap(arr[1], arr[i+1]);
        adjust(arr, 1, i);
    }
}

template <typename T>
void adjust(T* arr, const int ROOT, const int SIZE)
{
    T e = arr[ROOT];
    int i;

    for (i = ROOT << 1; i <= SIZE; i = i << 1)
    {
        if(i<SIZE && arr[i]<arr[i+1]) i++;
        if(arr[i] <= e) break;

        arr[i>>1] = arr[i];
    }
    arr[i>>1] = e;
}

/* Merge Sort */
template<typename T>
void myMerge(T* initList, T* resList, const int LEFT, const int MID, const int RIGHT)
{
    int i=LEFT, j = MID + 1, k = LEFT;
    while (i <= MID && j <= RIGHT) 
    {
        if (initList[i] <= initList[j]) resList[k++] = initList[i++];
        else resList[k++] = initList[j++];
    }

    if (i > MID) for (int t = j; t <= RIGHT; t++) resList[k++] = initList[t];
    else for (int t = i; t <= MID; t++) resList[k++] = initList[t];
}

template <typename T>
void myMergePass(T* initList, T* resList, const int SIZE, const int SUBSIZE)
{
    int i;
    for (i = 1; i <= SIZE - 2 * SUBSIZE + 1; i += 2 * SUBSIZE)
        myMerge(initList, resList, i, i+SUBSIZE-1, i+2*SUBSIZE-1);

    if ((i + SUBSIZE - 1)<SIZE) myMerge(initList, resList, i, i + SUBSIZE - 1, SIZE);
    else for (int j = i; j <= SIZE; j++) resList[j] = initList[j];
}

template <typename T>
void myMergeSort(T* arr, const int SIZE)
{
    T* tempList = new T[SIZE + 1];

    for (int i = 1; i < SIZE; i *= 2)
    {
        myMergePass(arr, tempList, SIZE, i);
        i*=2;
        myMergePass(tempList, arr, SIZE, i);
    }

    delete[] tempList;
}

template <typename T>
void myNatMerge(Queue<T>*& a, Queue<T>*& b)
{
    Queue<T>* res = new Queue<T>();

    while (!a->isEmpty() && !b->isEmpty())
    {
        if (a->getFront() <= b->getFront())
        {
            res->push(a->getFront());
            a->pop();
        }
        else
        {
            res->push(b->getFront());
            b->pop();
        }
    }

    while (!a->isEmpty())
    {
        res->push(a->getFront());
        a->pop();
    }
    while (!b->isEmpty())
    {
        res->push(b->getFront());
        b->pop();
    }

    delete b;
    b= a;
    delete b;

    a = res;
}

template <typename T>
void myNatMergeSort(T* arr, const int SIZE)
{
    Queue<T>** ques = new Queue<T>*[SIZE+1];
    Queue<int> actQ;
    for (int i = 0; i <= SIZE; i++)
        ques[i] = NULL;

    int qidx = 1;
    
    // �ʱ� �н� ����
    for (int i = 1; i <= SIZE; i++)
    {
        if (!ques[qidx]) ques[qidx] = new Queue<T>();
        if (!ques[qidx]->isEmpty() && arr[i] < ques[qidx]->getRear()) 
            ques[++qidx] = new Queue<T>();
        
        ques[qidx]->push(arr[i]);
    }

    for(int i=1; i<=qidx; i++) actQ.push(i);

    // ���ʺ��� 2������ ���� & ����
    while (actQ.getSize() > 1)
    {
        int aIdx = actQ.getFront();
        actQ.pop();
        int bIdx = actQ.getFront();
        actQ.pop();

        myNatMerge(ques[aIdx], ques[bIdx]);
        actQ.push(aIdx);
    }

    int res = actQ.getFront();
    for(int i=1; i<=SIZE; i++, ques[res]->pop())
        arr[i] = ques[res]->getFront();

    delete ques[res];
    delete[] ques;
}