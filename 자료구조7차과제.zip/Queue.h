#pragma once
#include "CommonHeader.h"

template <typename T>
class Queue
{
private:
    T* queue;
    int capacity;
    int front, rear;

    void doubleCapa();

public:
    Queue(int capa = 10);
    ~Queue();

    bool isEmpty();
    void push(T item);
    T getFront();
    T getRear();
    void pop();
    int getSize();
};

template<typename T>
void Queue<T>::doubleCapa()
{
    T* temp = new T[capacity * 2];
    int pos = 1;

    if (front < rear)
    {
        for (int i = (front + 1) % capacity; i < capacity; i++)
            temp[pos++] = queue[i];
    }
    else
    {
        for (int i = (front + 1) % capacity; i < capacity; i++)
            temp[pos++] = queue[i];

        for (int i = 0; i <= rear; i++)
            temp[pos++] = queue[i];
    }
    rear = capacity;
    capacity *= 2;
    front = 0;

    delete[] queue;
    queue = temp;
}

template<typename T>
Queue<T>::Queue(int capa)
{
    front = rear = 0;
    capacity = capa;

    queue = new T[capa];
}

template<typename T>
Queue<T>::~Queue()
{
    if (queue)
        delete[] queue;
}

template<typename T>
bool Queue<T>::isEmpty()
{
    return front == rear;
}

template<typename T>
void Queue<T>::push(T item)
{
    if ((rear + 1) % capacity == front)
        doubleCapa();
    else
        rear = (rear + 1) % capacity;
    queue[rear] = item;
}

template<typename T>
T Queue<T>::getFront()
{
    return queue[(front + 1) % capacity];
}

template<typename T>
T Queue<T>::getRear()
{
    return queue[rear];
}

template<typename T>
void Queue<T>::pop()
{
    if (front != rear)
        front = (front + 1) % capacity;
}

template<typename T>
int Queue<T>::getSize()
{
    if (front <= rear) return rear-front;
    else return capacity - front + rear;
}
