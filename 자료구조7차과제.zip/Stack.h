#pragma once
#include "CommonHeader.h"

template <typename T>
class Stack
{
protected:
    T* stack;
    int capacity;
    int top;

    void doubleCapacity();

public:
    Stack(int size = 10);
    ~Stack();

    void push(T& item);
    T getTop();
    void pop();
    bool isEmpty();
};

template <typename T>
Stack<T>::Stack(int size)
{
    capacity = size;
    stack = new T[capacity];
    top = 0;
}

template <typename T>
Stack<T>::~Stack()
{
    if (stack != NULL)
        delete[] stack;
}

template <typename T>
void Stack<T>::doubleCapacity()
{
    T* temp = new T[capacity * 2];

    for (int i = 0; i < top; i++)
        temp[i] = stack[i];

    delete[] stack;
    stack = temp;
}

template <typename T>
void Stack<T>::push(T& item)
{
    if (top + 1 == capacity)
        doubleCapacity();

    stack[top++] = item;
}

template <typename T>
void Stack<T>::pop()
{
    if (!top)
        return;
    else
        top--;
}

template <typename T>
T Stack<T>::getTop()
{
    if (isEmpty())
        return NULL;

    return stack[top-1];
}

template <typename T>
bool Stack<T>::isEmpty()
{
    if (!top)
        return true;

    return false;
}