#pragma once
#include <string>
using namespace std;

class Student
{
private:
    int id;
    int kor;
    int eng;
    int math;
    string name;

public:
    Student(int _id = 0, int _kor = 0, int _eng = 0, int _math = 0, string _name = " ")
    {
        id = _id;
        kor = _kor;
        eng = _eng;
        math = _math;
        name = _name;
    }
    Student& operator = (Student& s)
    {
        id = s.id; 
        kor = s.kor; 
        eng = s.eng; 
        math = s.math; 
        name = s.name;

        return *this;
    }

    bool operator < (Student& s) { return (kor+eng+math) < (s.kor + s.eng + s.math); }
    bool operator <= (Student& s) { return (kor + eng + math) <= (s.kor + s.eng + s.math); }
    bool operator ==(Student& s) { return (kor + eng + math) == (s.kor + s.eng + s.math); }
};