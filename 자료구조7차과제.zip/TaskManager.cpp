#include "TaskManager.h"

ostream& operator << (ostream& os, Student& s)
{
    return os;
}

void TaskManager::getMenu(int& sortType, int& dataType, int& arrayType, int& size)
{
    for (int i = 0; i < SORT_KIND; i++) 
        cout << "  " << i + 1 << ") " << SORT_NAME[i] << endl; 

    cout << ">> ������ ����(���� : -1) ? ";
    cin >> sortType;

    if(sortType==EXIT) return;
    sortType--; // adjust user input
    
    // RADIX SORT�� unsigned int ���� ���� RAD_SIZE(1�鸸)�� ���� �迭�� ���� ������ ����
    if (sortType == MOD_DEC_RADIX || sortType == MOD_HEX_RADIX || sortType == BIT_HEX_RADIX)
    {
        ArrayMaker am;
        unsigned int* arr = am.makeUIntArr(RAD_SIZE, (ARRAY_TYPE)RAND);
        chkRadSortTime(arr, RAD_SIZE, sortType);
        delete[] arr;
        return;
    }

    cout << "\n  1)���� 2)�Ǽ� 3)���ڿ� 4)�л�" << endl;
    cout << ">> ������ ������ Ÿ�� ? ";
    cin >> dataType;

    cout << "\n  1)�������� 2)�������� 3)����" << endl;
    cout << ">> �����迭�� ���Ļ��� ? ";
    cin >> arrayType;
    arrayType--; // adjust user input

    cout << "\n>> ������ �迭�� ũ�� ? ";
    cin >> size;
}

void TaskManager::sort(const int SORTTYPE, const int DATATYPE, const int ARRTYPE, const int SIZE)
{
    ArrayMaker am;

    cout << SORT_NAME[SORTTYPE];
    cout << " ������ �����մϴ� ... ";

    switch (DATATYPE)
    {
    case INTEGER: 
    {
        int* arr = am.makeIntArr(SIZE, (ARRAY_TYPE)ARRTYPE);
        chkSort<int>((int*)arr, SORTTYPE, ARRTYPE, SIZE);
        if (arr) delete[] arr;
        break;
    }
    case DOUBLE:
    {
        double* arr = am.makeDblArr(SIZE, (ARRAY_TYPE)ARRTYPE);
        chkSort<double>((double*)arr, SORTTYPE, ARRTYPE, SIZE);
        if (arr) delete[] arr;
        break;
    }
    case STRING:
    {
        string* arr = am.makeStrArr(SIZE, (ARRAY_TYPE)ARRTYPE);
        chkSort<string>((string*)arr, SORTTYPE, ARRTYPE, SIZE); 
        if (arr) delete[] arr;
        break;
    }
    case STUDENT:
    {
        Student* arr = am.makeStdArr(SIZE, (ARRAY_TYPE)ARRTYPE);
        chkSort<Student>((Student*)arr, SORTTYPE, ARRTYPE, SIZE);
        if (arr) delete[] arr;
        break;
    }
    }
}

void TaskManager::chkRadSortTime(unsigned int * arr, const int SIZE, const int SORTTYPE)
{
    clock_t start = clock();

    switch (SORTTYPE)
    {
    case MOD_DEC_RADIX: modDecRadixSort(arr, SIZE); break;
    case MOD_HEX_RADIX: modHexRadixSort(arr, SIZE); break;
    case BIT_HEX_RADIX: bitHexRadixSort(arr, SIZE); break;
    }

    clock_t end = clock();

    if (isSorted(arr, SIZE))
        cout << end - start << " ms " << endl << endl;
    else
        cout << "Array is Not Sorted" << endl << endl;
}