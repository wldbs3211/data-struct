#pragma once
#include "CommonHeader.h"
#include "ArrayMaker.h"
#include "MySort.h"
#include <algorithm>

class TaskManager
{
private:
    template <typename T>
    void chkSort(T* arr, const int SORTTYPE, const int ARRTYPE, const int SIZE);

    template <typename T>
    void chkSortTime(T* arr, const int SIZE, void(*fpSort)(T*, const int) = NULL, int(*fpCmp)(const void*, const void*) = NULL);
    void chkRadSortTime(unsigned int * arr, const int SIZE, const int SORTTYPE);

public:
    void getMenu(int& sortType, int& dataType, int& arrayType, int& size);
    void sort(const int SORTTYPE, const int DATATYPE, const int ARRTYPE, const int SIZE);

};

template<typename T>
void TaskManager::chkSortTime(T * arr, const int SIZE, void(*fpSort)(T *, const int), int(*fpCmp)(const void *, const void *))
{
    clock_t start = clock();

    if (fpSort) fpSort(arr, SIZE);
    else if (fpCmp) qsort(arr + 1, SIZE, sizeof(T), fpCmp);
    else std::sort(arr + 1, arr + 1 + SIZE);
    
    clock_t end = clock();
    
    if (isSorted(arr, SIZE))
        cout << end - start << " ms " << endl << endl;
    else
        cout << "Array is Not Sorted" << endl << endl;
}

template<typename T>
void TaskManager::chkSort(T* arr, const int SORTTYPE, const int ARRTYPE, const int SIZE)
{
    switch (SORTTYPE)
    {
    case BUBBLE: chkSortTime<T>(arr, SIZE, myBubbleSort); break;
    case SELECTION: chkSortTime<T>(arr, SIZE, mySelectionSort); break;
    case INSERTION: chkSortTime<T>(arr, SIZE, myInsertionSort); break;
    case LINKED_INSERTION: chkSortTime<T>(arr, SIZE, myLinkedInsertionSort); break;
    case BINARY_INSERTION: chkSortTime<T>(arr, SIZE, myBinaryInsertionSort); break;
    case QUICK: chkSortTime<T>(arr, SIZE, myQuickSort); break;
    case MEDIAN_OF_THREE_QUICK: chkSortTime<T>(arr, SIZE, myMotQuickSort); break;
    case MOT_STK_QUICK : chkSortTime<T>(arr, SIZE, myMotStkQuickSort); break;
    case MERGE: chkSortTime<T>(arr, SIZE, myMergeSort); break;
    case RECURSIVE_MERGE: chkSortTime<T>(arr, SIZE, myRMergeSort); break;
    case NAT_MERGE : chkSortTime<T>(arr, SIZE, myNatMergeSort); break;
    case HEAP: chkSortTime<T>(arr, SIZE, myHeapSort); break;
    case STD_SORT: chkSortTime<T>(arr, SIZE); break;
    case C_QSORT: chkSortTime<T>(arr, SIZE, NULL, cmp<T>); break;
    }
}