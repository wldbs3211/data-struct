#include "CommonHeader.h"
#include "TaskManager.h"

int main()
{
    TaskManager tm;
    int sortType, dataType, arrayType, size;
    
    while (true)
    {
        tm.getMenu(sortType, dataType, arrayType, size);
        if(sortType == EXIT) break;

        tm.sort(sortType, dataType, arrayType, size);
    }

    return 0;
}